
import designData from './design.json';
    
function __aux_code() {
    return {
        Win : designData[0],

    }
}
export default __aux_code
    